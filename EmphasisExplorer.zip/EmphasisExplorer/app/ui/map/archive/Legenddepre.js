define([], function(LegendCard) {
    return function Legend(map) {
        const self = this;


    }
})